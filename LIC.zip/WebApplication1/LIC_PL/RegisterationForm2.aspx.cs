﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ClassLibrary1;
using LIC_DAL;

namespace LIC_PL
{
    public partial class RegisterationForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Customer newCust = new Customer();
 
            newCust.CustomerName = TextBox2.Text;
            newCust.DOB = Convert.ToDateTime(TextBox3.Text);
            newCust.Address = TextBox4.Text;

            LICDAL dalobj = new LICDAL();
            if(dalobj.AddCustDAL(newCust, DropDownList1.SelectedItem.Text,DropDownList2.SelectedItem.Text)
                Label9.Text="Customer Added";
            else
                Label9.Text="Customer not added";
        }
    }
}