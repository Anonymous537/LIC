﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace LIC_DAL
{
    class LICConfiguration
    {
        private static string providerName;

        public static string ProviderName
        {
            get { return LICConfiguration.providerName; }
            set { LICConfiguration.providerName = value; }
        }
        private static string connectionString;

        public static string ConnectionString
        {
            get { return LICConfiguration.connectionString; }
            set { LICConfiguration.connectionString = value; }
        }

        static LICConfiguration()
        {
            providerName = ConfigurationManager.ConnectionStrings["LICConnection"].ProviderName;
            connectionString = ConfigurationManager.ConnectionStrings["LICConnection"].ConnectionString;

        }
    }
}
