﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Common;
using System.Data;
using ClassLibrary1;

namespace LIC_DAL
{
    public class LICDAL
    {
        public bool AddCustDAL(Customer newCust,string policy,string branch)
        {
            bool guestAdded = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "uspAddGuest";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@ipv_iGuestID";
                param.DbType = DbType.Int32;
                param.Value = newGuest.GuestID;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@ipv_vcGuestName";
                param.DbType = DbType.String;
                param.Value = newGuest.GuestName;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@ipv_vcGuestContactNumber";
                param.DbType = DbType.String;
                param.Value = newGuest.GuestContactNumber;
                command.Parameters.Add(param);

                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    guestAdded = true;
            }
            catch (DbException ex)
            {
                string errormessage;

                switch (ex.ErrorCode)
                {
                    case -2146232060:
                        errormessage = "Database Does NotExists Or AccessDenied";
                        break;
                    default:
                        errormessage = ex.Message;
                        break;
                }
                throw new GuestPhoneBookException(errormessage);
            }
            return guestAdded;

        }
    }
}
