﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    class Branch
    {
        public int BRANCHID { get; set; }
        public string BRANCHNAME { get; set; }
        public string BRANCHADDRESS { get; set; }
    }
}
