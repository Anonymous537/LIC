﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Policy
    {
        public int POLICYID { get; set; }
        public string POLICYNAME { get; set; }
        public int DURATION { get; set; }
        public decimal PREMIUM { get; set; }
        public decimal MATUARITY { get; set; }
    }
}
