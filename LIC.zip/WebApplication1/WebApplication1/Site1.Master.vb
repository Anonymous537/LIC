﻿Public Class Site1
    Inherits System.Web.UI.MasterPage

    

End Class